package com.skyline.wallpaper

import android.Manifest
import android.app.Activity
import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Bundle
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val cities = listOf(
        Triple("Delhi", 28.61, 77.21), Triple("Mumbai", 19.08, 72.88), Triple("Bengaluru", 12.97, 77.59),
        Triple("Kolkata", 22.57, 88.36), Triple("Chennai", 13.08, 80.27), Triple("Hyderabad", 17.39, 78.49),
        Triple("Paris", 48.86, 2.35), Triple("London", 51.51, -0.13), Triple("New York", 40.71, -74.01),
        Triple("Dubai", 25.20, 55.27), Triple("Tokyo", 35.68, 139.69), Triple("Sydney", -33.87, 151.21)
    )
    private lateinit var prefs: SharedPreferences
    private lateinit var info: TextView

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        prefs = getSharedPreferences("scene", MODE_PRIVATE)
        val d = resources.displayMetrics.density
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((24 * d).toInt(), (48 * d).toInt(), (24 * d).toInt(), (24 * d).toInt())
        }
        col.addView(TextView(this).apply { text = "Skyline Live"; textSize = 28f })
        info = TextView(this).apply { textSize = 15f; setPadding(0, (8 * d).toInt(), 0, (16 * d).toInt()) }
        col.addView(info)
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("शहर चुनो…") + cities.map { it.first })
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) {
                if (i > 0) save(cities[i - 1].second, cities[i - 1].third)
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        col.addView(sp)
        col.addView(Button(this).apply {
            text = "मेरी लोकेशन इस्तेमाल करो"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) useLocation()
                else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), 1)
            }
        })
        col.addView(CheckBox(this).apply {
            text = "डेमो: 1 दिन = 2 मिनट (टेस्ट के लिए)"
            isChecked = prefs.getBoolean("demo", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("demo", on).apply() }
        })
        col.addView(Button(this).apply {
            text = "वॉलपेपर लगाओ"
            setOnClickListener {
                val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
                    .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, ComponentName(this@MainActivity, SkylineService::class.java))
                try { startActivity(i) } catch (e: ActivityNotFoundException) {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                }
            }
        })
        setContentView(ScrollView(this).apply { addView(col) })
        refresh()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) useLocation()
    }

    @Suppress("MissingPermission")
    private fun useLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val loc = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
        if (loc == null) Toast.makeText(this, "लोकेशन नहीं मिली। Maps खोलकर दोबारा कोशिश करो या शहर चुनो।", Toast.LENGTH_LONG).show()
        else save(loc.latitude, loc.longitude)
    }

    private fun save(lat: Double, lon: Double) {
        prefs.edit().putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).apply()
        refresh()
    }

    private fun refresh() {
        info.text = if (prefs.contains("lat")) "लोकेशन: %.2f, %.2f".format(prefs.getFloat("lat", 0f), prefs.getFloat("lon", 0f))
        else "लोकेशन: फ़ोन के टाइमज़ोन से अंदाज़ा"
    }
}
