package com.skyline.wallpaper

import kotlin.math.*

/** Sun and moon geometry from clock + latitude/longitude (accuracy ~0.01 deg for the sun). */
object Solar {
    /** elev: degrees above horizon. h: -1 at rise, 0 at transit, +1 at set (normalised to the real day length). */
    class Pos(val elev: Double, val h: Double)

    private fun jd(ms: Long) = ms / 86400000.0 + 2440587.5
    private fun wrap(v: Double, m: Double) = ((v % m) + m) % m

    /** Lunar cycle 0..1 (0 = new, 0.5 = full). */
    fun moonFrac(ms: Long) = wrap(jd(ms) - 2451550.1, 29.530588853) / 29.530588853

    fun position(ms: Long, lat: Double, lon: Double, moonFrac: Double = -1.0): Pos {
        val n = jd(ms) - 2451545.0
        val g = Math.toRadians(wrap(357.528 + 0.9856003 * n, 360.0))
        val lam = Math.toRadians(wrap(280.460 + 0.9856474 * n, 360.0) + 1.915 * sin(g) + 0.020 * sin(2 * g))
        val eps = Math.toRadians(23.439 - 4e-7 * n)
        val ra = atan2(cos(eps) * sin(lam), cos(lam))
        var dec = asin(sin(eps) * sin(lam))
        var h = Math.toRadians(wrap(wrap(18.697374558 + 24.06570982441908 * n, 24.0) * 15.0 + lon, 360.0)) - ra
        if (moonFrac >= 0) { val a = 2 * PI * moonFrac; h -= a; dec *= cos(a) }
        val la = Math.toRadians(lat)
        val el = asin(sin(la) * sin(dec) + cos(la) * cos(dec) * cos(h))
        val c = -tan(la) * tan(dec)
        val h0 = if (c >= 1) 0.05 else if (c <= -1) PI else acos(c)
        return Pos(Math.toDegrees(el), atan2(sin(h), cos(h)) / h0)
    }
}
