package com.skyline.wallpaper

import android.content.Context
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.util.Random
import java.util.TimeZone
import kotlin.math.*

class SkylineService : WallpaperService() {
    override fun onCreateEngine(): Engine = SceneEngine()

    private fun bmp(id: Int): Bitmap =
        BitmapFactory.decodeResource(resources, id, BitmapFactory.Options().apply { inScaled = false })

    inner class SceneEngine : Engine() {
        private val ui = Handler(Looper.getMainLooper())
        private val tick = Runnable { frame() }
        private val sun = bmp(R.drawable.sun)
        private val city = bmp(R.drawable.city)
        private val tower = bmp(R.drawable.tower)
        private val birds = bmp(R.drawable.birds)
        private val d = resources.displayMetrics.density
        private val PIF = PI.toFloat()

        private var W = 1f; private var H = 1f; private var hz = 1f; private var xOff = .5f
        private var lat = 28.61; private var lon = 77.21; private var demo = false
        private var visible = false
        private val demoT0 = SystemClock.elapsedRealtime()
        private val demoBase = System.currentTimeMillis()

        private val paint = Paint()
        private val rect = RectF()
        private val rnd = Random(7)
        private val sky = FloatArray(6)
        private val amb = FloatArray(3)

        // [elevation, top r,g,b, bottom r,g,b]
        private val skyKeys = arrayOf(
            floatArrayOf(30f, 47f, 127f, 214f, 169f, 216f, 255f), floatArrayOf(10f, 74f, 144f, 217f, 191f, 227f, 255f),
            floatArrayOf(3f, 62f, 111f, 176f, 255f, 178f, 122f), floatArrayOf(-1f, 59f, 90f, 154f, 255f, 154f, 90f),
            floatArrayOf(-5f, 42f, 42f, 94f, 181f, 82f, 122f), floatArrayOf(-10f, 20f, 31f, 74f, 74f, 58f, 110f),
            floatArrayOf(-16f, 12f, 18f, 48f, 42f, 42f, 90f), floatArrayOf(-22f, 5f, 8f, 22f, 20f, 28f, 64f))
        // [elevation, ambient light multiplier r,g,b]
        private val ambKeys = arrayOf(
            floatArrayOf(25f, 1f, 1f, 1f), floatArrayOf(4f, 1f, .78f, .6f), floatArrayOf(-3f, .62f, .45f, .52f),
            floatArrayOf(-9f, .30f, .30f, .45f), floatArrayOf(-18f, .13f, .16f, .30f))

        private val starX = FloatArray(150) { rnd.nextFloat() }
        private val starY = FloatArray(150) { rnd.nextFloat() }
        private val starR = FloatArray(150) { (.5f + rnd.nextFloat()) * d }
        private val starP = FloatArray(150) { rnd.nextFloat() * 6.28f }
        private val cloudX = FloatArray(6) { rnd.nextFloat() * 1.5f }
        private val cloudY = FloatArray(6) { rnd.nextFloat() }
        private val cloudS = FloatArray(6) { .6f + rnd.nextFloat() * .9f }
        private val cloudV = FloatArray(6) { .004f + rnd.nextFloat() * .006f }
        private val win: FloatArray = run {
            val l = ArrayList<Float>(); var tries = 0
            while (l.size < 900 && tries++ < 40000) {
                val x = rnd.nextInt(city.width); val y = (city.height * (.12f + rnd.nextFloat() * .7f)).toInt()
                val px = city.getPixel(x, y)
                if (Color.alpha(px) > 240 && Color.red(px) + Color.green(px) + Color.blue(px) < 330) { l.add(x.toFloat()); l.add(y.toFloat()) }
            }
            l.toFloatArray()
        }

        private val far = Path(); private val near = Path(); private val ground = Path()
        private var trees = FloatArray(0)
        private val moonCm = ColorMatrixColorFilter(ColorMatrix().apply {
            setSaturation(.05f)
            postConcat(ColorMatrix(floatArrayOf(1.2f, 0f, 0f, 0f, 50f, 0f, 1.2f, 0f, 0f, 50f, 0f, 0f, 1.25f, 0f, 55f, 0f, 0f, 0f, 1f, 0f)))
        })

        // ---------- lifecycle ----------
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            W = width.toFloat(); H = height.toFloat(); hz = H * .60f
            ridge(far, .20f, 3.1f, 0f); ridge(near, .12f, 5.3f, 1.7f)
            ground.reset(); ground.moveTo(-W * .1f, H)
            var x = -W * .1f
            while (x <= W * 1.1f) { ground.lineTo(x, gy(x)); x += W / 40f }
            ground.lineTo(W * 1.1f, H); ground.close()
            val r = Random(11)
            trees = Array(16) { floatArrayOf(r.nextFloat() * W * 1.1f - W * .05f, 0f, 0f) }.onEach {
                it[1] = gy(it[0]) + H * (.02f + r.nextFloat() * .13f); it[2] = H * (.016f + (it[1] - hz) / H * .07f)
            }.sortedBy { it[1] }.flatMap { it.toList() }.toFloatArray()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v; ui.removeCallbacks(tick)
            if (v) { readPrefs(); ui.post(tick) }
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) { visible = false; ui.removeCallbacks(tick); super.onSurfaceDestroyed(holder) }
        override fun onDestroy() { visible = false; ui.removeCallbacks(tick); super.onDestroy() }
        override fun onOffsetsChanged(x: Float, y: Float, xs: Float, ys: Float, xp: Int, yp: Int) { xOff = x }

        private fun readPrefs() {
            val p = this@SkylineService.getSharedPreferences("scene", Context.MODE_PRIVATE)
            demo = p.getBoolean("demo", false)
            if (p.contains("lat")) { lat = p.getFloat("lat", 28.61f).toDouble(); lon = p.getFloat("lon", 77.21f).toDouble() }
            else {
                val tz = TimeZone.getDefault()
                if (tz.id == "Asia/Kolkata") { lat = 28.61; lon = 77.21 } else { lat = 25.0; lon = tz.rawOffset / 3600000.0 * 15.0 }
            }
        }

        private fun frame() {
            if (!visible) return
            val sh = surfaceHolder
            var cv: Canvas? = null
            try {
                cv = try { sh.lockHardwareCanvas() } catch (e: Exception) { sh.lockCanvas() }
                if (cv != null) render(cv)
            } catch (e: Exception) {
            } finally {
                if (cv != null) try { sh.unlockCanvasAndPost(cv) } catch (e: Exception) {}
            }
            ui.removeCallbacks(tick)
            if (visible) ui.postDelayed(tick, 33)
        }

        // ---------- helpers ----------
        private fun P(): Paint { paint.reset(); paint.isAntiAlias = true; paint.isFilterBitmap = true; return paint }
        private fun gy(x: Float) = hz + H * .085f + sin(x / W * 4f + 1f) * H * .018f + sin(x / W * 11f) * H * .006f
        private fun par(depth: Float) = (.5f - xOff) * W * .06f * depth
        private fun tint(r: Int, g: Int, b: Int) = Color.rgb((r * amb[0]).toInt(), (g * amb[1]).toInt(), (b * amb[2]).toInt())
        private fun blend(a: Int, b: Int, f: Float) = Color.rgb(
            (Color.red(a) * (1 - f) + Color.red(b) * f).toInt(), (Color.green(a) * (1 - f) + Color.green(b) * f).toInt(),
            (Color.blue(a) * (1 - f) + Color.blue(b) * f).toInt())

        private fun keys(k: Array<FloatArray>, e: Float, out: FloatArray) {
            if (e >= k[0][0]) { for (i in out.indices) out[i] = k[0][i + 1]; return }
            for (n in 1 until k.size) if (e >= k[n][0]) {
                val a = k[n - 1]; val b = k[n]; val f = (a[0] - e) / (a[0] - b[0])
                for (i in out.indices) out[i] = a[i + 1] + (b[i + 1] - a[i + 1]) * f
                return
            }
            for (i in out.indices) out[i] = k.last()[i + 1]
        }

        private fun ridge(path: Path, amp: Float, f: Float, ph: Float) {
            path.reset(); path.moveTo(-W * .15f, hz + 10f)
            var x = -W * .15f
            while (x <= W * 1.15f) {
                val u = x / W
                path.lineTo(x, hz - H * amp * (.3f + .7f * (1f - abs(sin(u * f * PIF + ph))) * (.75f + .25f * sin(u * f * 9f + ph))))
                x += W / 60f
            }
            path.lineTo(W * 1.15f, hz + 10f); path.close()
        }

        // ---------- scene ----------
        private fun render(c: Canvas) {
            val now = if (demo) demoBase + (SystemClock.elapsedRealtime() - demoT0) * 720 else System.currentTimeMillis()
            val t = SystemClock.elapsedRealtime() / 1000f
            val sp = Solar.position(now, lat, lon)
            val mf = Solar.moonFrac(now)
            val mp = Solar.position(now, lat, lon, mf)
            val el = sp.elev.toFloat()
            val dark = ((-el - 3f) / 12f).coerceIn(0f, 1f)
            val day = ((el + 3f) / 8f).coerceIn(0f, 1f)
            keys(skyKeys, el, sky); keys(ambKeys, el, amb)
            val skyTop = Color.rgb(sky[0].toInt(), sky[1].toInt(), sky[2].toInt())
            val skyBot = Color.rgb(sky[3].toInt(), sky[4].toInt(), sky[5].toInt())
            val lit = LightingColorFilter(tint(255, 255, 255), 0)

            // sky
            P().also { it.shader = LinearGradient(0f, 0f, 0f, hz, skyTop, skyBot, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, W, H, it) }

            // stars
            if (dark > 0f) {
                val q = P()
                for (i in starX.indices) {
                    val a = dark * (.55f + .45f * sin(t * 1.7f + starP[i]))
                    q.color = Color.argb((a * 255).toInt().coerceIn(0, 255), 255, 250, 235)
                    c.drawCircle(starX[i] * W, starY[i] * hz * .95f, starR[i], q)
                }
            }

            // moon (real phase and position)
            if (mp.elev > -3) {
                val mx = W * (.5f + .45f * mp.h.toFloat().coerceIn(-1.2f, 1.2f)) + par(.2f)
                val my = hz - mp.elev.toFloat() / 90f * hz * .95f
                val r = min(W, H) * .045f
                val k = ((1 - cos(2 * PI * mf)) / 2).toFloat()
                P().also {
                    it.shader = RadialGradient(mx, my, r * 5f, Color.argb((90 * (.3f + dark) * k).toInt(), 200, 215, 255), Color.argb(0, 200, 215, 255), Shader.TileMode.CLAMP)
                    c.drawCircle(mx, my, r * 5f, it)
                }
                val layer = c.saveLayer(mx - r * 1.1f, my - r * 1.1f, mx + r * 1.1f, my + r * 1.1f, null)
                P().also { it.colorFilter = moonCm; it.alpha = (255 * (.35f + .65f * dark)).toInt(); rect.set(mx - r, my - r, mx + r, my + r); c.drawBitmap(sun, null, rect, it) }
                P().also {
                    it.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_OUT); it.color = Color.BLACK
                    c.drawCircle(mx + (if (mf < .5) -1f else 1f) * 2f * r * k, my, r * 1.02f, it)
                }
                c.restoreToCount(layer)
            }

            // sun (real position, rotating surface)
            if (el > -8f) {
                val sx = W * (.5f + .45f * sp.h.toFloat().coerceIn(-1.15f, 1.15f)) + par(.2f)
                val sy = hz - el / 90f * hz * .95f
                val r = min(W, H) * .075f
                val k = ((el + 8f) / 10f).coerceIn(0f, 1f)
                val warm = ((14f - el) / 14f).coerceIn(0f, 1f) * k
                P().also {
                    it.shader = RadialGradient(sx, sy, W * .9f, Color.argb((120 * warm).toInt(), 255, 140, 60), Color.argb(0, 255, 140, 60), Shader.TileMode.CLAMP)
                    c.drawCircle(sx, sy, W * .9f, it)
                    it.shader = RadialGradient(sx, sy, r * 6f, Color.argb((170 * k).toInt(), 255, 235, 170), Color.argb(0, 255, 235, 170), Shader.TileMode.CLAMP)
                    c.drawCircle(sx, sy, r * 6f, it)
                }
                val hot = ((12f - el) / 12f).coerceIn(0f, 1f)
                c.save(); c.rotate(t * 3f, sx, sy)
                P().also {
                    it.colorFilter = LightingColorFilter(Color.rgb(255, (255 - 70 * hot).toInt(), (255 - 130 * hot).toInt()), 0)
                    it.alpha = (255 * k).toInt(); rect.set(sx - r, sy - r, sx + r, sy + r); c.drawBitmap(sun, null, rect, it)
                }
                c.restore()
            }

            // clouds
            val cc = tint(255, 255, 255)
            val q = P()
            for (i in 0 until 6) {
                val x = ((cloudX[i] + t * cloudV[i]) % 1.5f - .25f) * W + par(.3f)
                val y = cloudY[i] * hz * .55f + hz * .05f
                val s = cloudS[i] * W * .09f
                for (j in 0..2) {
                    q.color = Color.argb(60, Color.red(cc), Color.green(cc), Color.blue(cc))
                    val w = s * (1.5f - j * .3f); val hh = s * (.5f - j * .1f)
                    c.drawOval(x - w, y - hh, x + w, y + hh, q); c.drawOval(x + w * .5f - w * .6f, y - hh * 1.4f, x + w * .5f + w * .6f, y + hh * .5f, q)
                }
            }

            // birds
            if (day > 0f) for (i in 0..1) {
                val sc = W * (.34f - i * .14f) / birds.width
                val x = ((t * (.018f - i * .006f) + i * .45f) % 1.6f - .45f) * W
                val y = hz * (.28f + i * .17f) + sin(t * .7f + i * 2f) * H * .012f
                c.save(); c.translate(x, y); c.scale(sc, sc * (1f + .14f * sin(t * (8f + i * 2f))))
                P().also { it.alpha = (235 * day).toInt(); c.drawBitmap(birds, -birds.width / 2f, -birds.height / 2f, it) }
                c.restore()
            }

            // mountains
            c.save(); c.translate(par(.35f), 0f)
            P().also { it.color = blend(tint(157, 182, 208), skyBot, .3f); c.drawPath(far, it) }
            c.restore(); c.save(); c.translate(par(.5f), 0f)
            P().also { it.color = blend(tint(109, 143, 176), skyBot, .15f); c.drawPath(near, it) }
            c.restore()

            // city + lit windows
            val cw = W * 1.06f; val sc = cw / city.width; val ch = city.height * sc
            val cl = (W - cw) / 2f + par(.55f); val cb = hz + H * .115f
            P().also { it.colorFilter = lit; rect.set(cl, cb - ch, cl + cw, cb); c.drawBitmap(city, null, rect, it) }
            if (dark > 0f) {
                val w = P()
                for (i in 0 until win.size step 2) {
                    val th = ((i / 2) * 37 % 100) / 100f
                    if (th < dark) {
                        w.color = Color.argb((200 * (.8f + .2f * sin(t + i))).toInt(), 255, 214, 130)
                        val wx = cl + win[i] * sc; val wy = cb - ch + win[i + 1] * sc
                        c.drawRect(wx, wy, wx + 2.4f * sc, wy + 3.2f * sc, w)
                    }
                }
            }

            // Eiffel Tower (floodlit gold at night)
            val th = H * .30f; val ts = th / tower.height; val tw = tower.width * ts
            val tx = W * .56f + par(.7f); val tb = hz + H * .125f
            if (dark > 0f) P().also {
                it.shader = RadialGradient(tx, tb - th * .45f, th * .8f, Color.argb((90 * dark).toInt(), 255, 176, 70), Color.argb(0, 255, 176, 70), Shader.TileMode.CLAMP)
                c.drawCircle(tx, tb - th * .45f, th * .8f, it)
            }
            rect.set(tx - tw / 2, tb - th, tx + tw / 2, tb)
            P().also { it.colorFilter = lit; c.drawBitmap(tower, null, rect, it) }
            if (dark > 0f) {
                P().also { it.colorFilter = PorterDuffColorFilter(Color.rgb(255, 184, 77), PorterDuff.Mode.SRC_ATOP); it.alpha = (200 * dark).toInt(); c.drawBitmap(tower, null, rect, it) }
                val s = P()
                for (i in 0 until 24) {
                    if (((t * 6f).toInt() + i * 5) % 4 != 0) continue
                    val f = (i * .618f) % 1f
                    val hw = tw * .5f * (1f - f) * .8f
                    s.color = Color.argb((255 * dark).toInt(), 255, 250, 225)
                    c.drawCircle(tx + ((i * 7) % 11 / 11f - .5f) * 2f * hw, tb - th * (.05f + .9f * f), 2.2f * d, s)
                }
            }

            // greenery
            c.save(); c.translate(par(.9f), 0f)
            P().also {
                it.shader = LinearGradient(0f, hz + H * .07f, 0f, H, tint(79, 154, 74), tint(47, 107, 53), Shader.TileMode.CLAMP)
                c.drawPath(ground, it)
            }
            val g = P()
            for (k in 0 until trees.size step 3) {
                val x = trees[k]; val by = trees[k + 1]; val s = trees[k + 2]; val sw = sin(t * 1.3f + x * .01f) * s * .06f
                g.color = tint(74, 54, 38); c.drawRect(x - s * .09f, by - s * 1.2f, x + s * .09f, by, g)
                g.color = tint(45, 106, 48)
                c.drawCircle(x + sw, by - s * 1.6f, s * .85f, g)
                c.drawCircle(x - s * .5f + sw * .7f, by - s * 1.15f, s * .65f, g)
                c.drawCircle(x + s * .5f + sw * .7f, by - s * 1.15f, s * .65f, g)
                g.color = tint(70, 140, 68); c.drawCircle(x + sw - s * .2f, by - s * 1.8f, s * .45f, g)
            }
            c.restore()
        }
    }
}
